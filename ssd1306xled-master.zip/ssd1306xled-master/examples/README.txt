SSD1306 - Driver for SSD1306 controlled OLDE displays


This program demonstrates the use of the SSD1306 library.

To make, execute:
	$ make

To upload, execute:
	$ avrdude -c usbasp -p t85 -U flash:w:"main.hex":a


