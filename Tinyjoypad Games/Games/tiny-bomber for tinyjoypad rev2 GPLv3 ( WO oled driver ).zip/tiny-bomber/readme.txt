*********************************************************************
          ABOUT THE NEW SOURCE CODE DISTRIBUTION METHOD
*********************************************************************

    All distributed source code is released under the GPLv.3 license.
The source code for the game is complete and functional, only the function
calls for the oled screen are missing, but all the important functions 
are predefined in the Tinydriver.h file. All you have to do is fill the 
functions with the graphic librarie of your choice.

    Sorry for the inconvenience this new way of distributing source codes
could cause you, but it is the temporary solution to avoid irregularities
or discontent on the part of the coders of the graphics libraries. This way,
the distributed code does not cause any licensing conflicts.

    I continue to work hard to solve this problem, but all the graphics
libraries that I find for attiny85, are derivatives of derivatives of
derivatives ..., and I have to find the starting source, and know the 
original creator of this library and under which license he released it,
so that I could copyright the right person under the right license.
    If you have any relevant information related to this topic,
 let me know at electro_l.i.b@tinyjoypad.com
